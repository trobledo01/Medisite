package com.pia.MediSite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediSiteApplication.class, args);
	}

}
