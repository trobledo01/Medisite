package com.pia.MediSite.Services.Medico;
package com.pia.MediSite.Entity.medico;


import com.pia.MediSite.Entity.medico.Medico;
import com.pia.MediSite.Repository.Medico.CiudadRepository;
import com.pia.MediSite.Repository.Medico.EspecialidadRepository;
import com.pia.MediSite.Repository.Medico.MedicoRepository;

import java.util.List;

public interface MedicoService {
    List<Medico> buscarPorEspecialidad(Long especialidadId) {}

    List<Medico> buscarPorCiudad(Long ciudadId) {}

    List<HorarioMedico> obtenerHorariosMedico(Long medicoId) {}

    HorarioMedico agregarHorarioMedico(Long medicoId, HorarioMedico horario) {
    }

    public void eliminarHorarioMedico(Long medicoId, Long horarioId) {
        Medico medico = medicoRepository.findById(medicoId)
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado"));
        HorarioMedico horario = horarioMedicoRepository.findById(horarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Horario no encontrado"));
        if (!horario.getMedico().equals(medico)) {
            throw new IllegalArgumentException("El horario no pertenece a este médico");
        }
        horarioMedicoRepository.delete(horario);
    }

    // Otros métodos de servicio según sea necesario
}
