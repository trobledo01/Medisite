package com.pia.MediSite.Repository.Medico;

import com.pia.MediSite.Entity.medico.HorarioMedico;
import com.pia.MediSite.Entity.medico.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HorarioMedicoRepository extends JpaRepository<HorarioMedico, Long> {
    List<HorarioMedico> findByMedico(Medico medico);
}
