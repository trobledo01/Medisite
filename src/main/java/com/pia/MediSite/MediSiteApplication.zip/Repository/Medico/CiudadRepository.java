package com.pia.MediSite.Repository.Medico;

import com.pia.MediSite.Entity.medico.Ciudad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CiudadRepository extends JpaRepository<Ciudad, Long> {}
